# # @Time : 2021/11/6 10:38
# # @Author: ZWX
# # @Email: 935721546@qq.com
# # @File : TestDemo.py
# import torch
#
#
# def TestDemo1():
#     # 初始化x为3X3的值为1的tensor张量，并将requires_grad设置为true（允许其进行梯度）
#     x = torch.ones(3, 3, requires_grad=True)
#     print(x)
#     print(x.grad_fn)
#     # 每一个tensor都有一个.grad_fn属性，该属性创建该Tensor的Function,就是说Tensor是不是通过某些运算得到的，若是，则grad_fn返回一个与运算相关的对象，否则是None
#     # 注意，由于x是直接创建的，所以没有grad_fn,而y是通过加法操作创建的，
#     y = x + 2
#     print(y)
#     print(y.grad_fn)
#     z = y * y
#     print(z)
#     print(z.grad_fn)
#
#
# def TestDemo2():
#     a = torch.randn(4, 4)  # 默认情况下requires_grad为false
#     print(a)
#     a = (a * 3) / (a - 1)
#     print(a)
#     print(a.requires_grad)
#     a.requires_grad_(True)
#     print(a.requires_grad)
#     b = (a * a).sum()
#     print(b)
#     print(b.grad_fn)
#
#
# def TestDemo3():
#     x = torch.tensor([1.0, 2.0, 3.0, 4.0], requires_grad=True)
#     y = 2 * x
#     z = y.view(2, 2)
#     print(z)
#     v = torch.tensor([[1.0, 0.1], [0.01, 0.001]], dtype=torch.float)
#     z.backward(v)
#     print(x.grad)
#     x = torch.tensor(1.0, requires_grad=True)
#     y1 = x ** 2
#     with torch.no_grad():  # 直接设定没有梯度执行
#         y2 = x ** 3
#     y3 = y1 + y2
#     y3.backward()
#     print(x.grad)
#
#
# if __name__ == '__main__':
#     TestDemo3()

memo = {}


def L(nums, i):
    if i in memo:
        return memo[i]
    if i == len(nums) - 1:
        return 1
    max_len = 1
    for j in range(i + 1, len(nums)):
        if nums[j] > nums[i]:
            max_len = max(max_len, L(nums, j) + 1)
    memo[i] = max_len
    return max_len


def length_of_nums(nums):
    return max(L(nums, i) for i in range(len(nums)))


def length_of_num(nums):
    n = len(nums)
    L = [1] * n
    for i in reversed(range(n)):
        for j in range(i + 1, n):
            if nums[j] > nums[i]:
                L[i] = max(L[i], L[j] + 1)
    return max(L)


nums = [1, 5, 2, 4, 3]
print(length_of_num(nums))
print(length_of_nums(nums))

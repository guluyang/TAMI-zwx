# @Time : 2021/8/7 14:23
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : NewEmbedding.py
import numpy as np
from scipy.spatial.distance import cdist

from MIDIE.DIP import DIP
from MILFrame.MILTool import MILTool, get_ten_fold_index


class NewEmbedding:
    def __init__(self, tr_index, bags):
        self.tr_index = tr_index
        self.bags = bags
        self.discriminative_instance = self.__DIP()
        self.embedding_vector = self.__embedding_all_bag()

    def __DIP(self):
        test = DIP(self.bags[self.tr_index], 0.001)
        return test.discriminative_instance

    def __embedding_all_bag(self):
        embedding_vector = []
        for bag_i in range(self.bags.shape[0]):
            # print(self.bags[bag_i][-1])
            embedding_vector.append(self.__embedding_single_bag(self.bags[bag_i]))
        return np.array(embedding_vector)

    def __embedding_single_bag(self, bag):
        ins_space_to_bag = []
        # print(bag[-1])
        for ins in bag[0][:, :-1]:
            ins_space_to_bag.append(ins)
        ins_space_to_bag = np.array(ins_space_to_bag)

        bag_vector = np.zeros(len(self.discriminative_instance)).astype('float64')
        if bag[-1] == 1:
            for ins_i in range(len(self.discriminative_instance)):
                dis_instance_bag = cdist(ins_space_to_bag, [self.discriminative_instance[ins_i]])
                bag_vector[ins_i] = (max(max(dis_instance_bag)))

        else:
            for ins_i in range(len(self.discriminative_instance)):
                dis_instance_bag = cdist(ins_space_to_bag, [self.discriminative_instance[ins_i]])
                bag_vector[ins_i] = (min(max(dis_instance_bag)))
        # print(bag_vector)

        temp_single_vector = np.sign(bag_vector) * np.sqrt(np.abs(bag_vector))
        temp_norm = np.linalg.norm(temp_single_vector)
        temp_single_vector = temp_single_vector / temp_norm
        return temp_single_vector


if __name__ == '__main__':
    file_path = "D:/Data/data_zero/benchmark/fox.mat"
    mil = MILTool(file_path)
    bags = mil.bags
    train_index, te_index = get_ten_fold_index(bags)
    test1 = NewEmbedding(bags=bags, tr_index=train_index[1])
    vector = test1.embedding_vector
    print(vector[train_index[1]])
    print(type(vector))

# @Time : 2021/5/12 10:20
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : DIEPredict.py
# @Time : 2021/4/10 15:52
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : DIEPredict.py

import time
import warnings

# import warnings
#
# warnings.filterwarnings('ignore')
import numpy as np
from sklearn.metrics import accuracy_score

from MIDIE.DIE import DIE
from MILFrame.MILTool import MILTool, get_ten_fold_index

# from MIL_MIDIE.SMDP.smdp import SmDp
# from MIL_MIDIE.miVLAD.VLAD import DpAm
warnings.filterwarnings('ignore')


class DIEPredict:
    def __init__(self, file_path, bags_status, embed_status, ratio_instance_to_bag,
                 num_discriminative_instance, bags=None):
        self.file_path = file_path
        self.bags_status = bags_status
        self.embed_status = embed_status
        self.ra_ins = ratio_instance_to_bag
        self.num_dis_ins = num_discriminative_instance
        self.bags = bags
        self.__DIEPredict()

    def __DIEPredict(self):
        MIL = MILTool(para_file_name=self.file_path, bags=self.bags)
        bags = MIL.bags
        bags_label = MIL.bags_label
        num_fold = 10

        accuracy_res_score = np.zeros(4).astype('float64')
        accuracy_std = [[], [], [], []]
        spend_time = 0
        for i in range(num_fold):
            # The four Classifiers.
            start_time = time.process_time()
            RSVM_estimator = MIL.get_classifier('rbf_svm')

            accuracy_measure_score = np.zeros(4).astype('float64')
            fl_measure_score = np.zeros(4).astype('float64')
            roc_measure_score = np.zeros(4).astype('float64')

            tr_index, te_index = get_ten_fold_index(bags)
            temp_f1_score = 10
            temp_acc_score = 10
            temp_roc_score = 10
            for j in range(10):
                # get_bar(i, j)
                tr_bags = bags[tr_index[j]]
                tr_label_true = bags_label[tr_index[j]]
                te_bags = bags[te_index[j]]
                te_label_true = bags_label[te_index[j]]

                # Step 1. Call the algorithm to get the mapping vector.
                test_Demo = DIE(bags, tr_index[j], self.bags_status, self.embed_status, self.ra_ins,
                                self.num_dis_ins).embedding_vector

                tr_embedding_vector = test_Demo[tr_index[j]]
                te_embedding_vector = test_Demo[te_index[j]]

                # Step 2.3.1 This is a DTree classification model.
                RSVM_model = RSVM_estimator.fit(tr_embedding_vector, tr_label_true)
                te_label_predict_RSVM = RSVM_model.predict(te_embedding_vector)
                accuracy_measure_score[3] += accuracy_score(te_label_true, te_label_predict_RSVM)

                # roc_measure_score[3] += roc_auc_score(te_label_true, te_label_predict_RSVM)

            accuracy_res_score[3] += accuracy_measure_score[3] / temp_acc_score  # RSVM  acc

            accuracy_std[3].append(accuracy_measure_score[3] * temp_acc_score)  # RSVM  std

            RSVM_acc_res = "&$%.1f" % (accuracy_res_score[3] * 10) + "_{\pm%.2f" % (np.std(accuracy_std[3])) + "}$"
            end_time = time.process_time()
            spend_time += end_time - start_time
        print("the time spend:%.6f" % (spend_time/10))


if __name__ == '__main__':
    file_name = "D:/Data/data_zero/Mutagenesis/mutagenesis1.mat"
    para_name = file_name[30:]
    # DIEPredict(file_name=file_name, para_name=para_name)

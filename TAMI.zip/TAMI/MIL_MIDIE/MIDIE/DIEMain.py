# @Time : 2021/5/16 10:09
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : DIEMain.py
from MIDIE.DIEPredict import DIEPredict


# from MIDIE.DIEPredict_Test import DIEPredict

def test(path):
    bag_status = ['g']
    embed_status = ['con']
    instance = [1, 2, 3, 4, 5]
    for bag_i in range(len(bag_status)):
        for embed_i in range(len(embed_status)):
            for i in range(len(instance)):
                print(bag_status[bag_i], embed_status[embed_i], i)
                DIEPredict(file_path, bag_status[bag_i], embed_status[bag_i], 0.01, instance[i])


if __name__ == '__main__':
    file_path = "D:/Data/data_zero/biocreative/component.mat"
    file_path_all = ["D:/Data/data_zero/biocreative/component.mat"
                     "D:/Data/data_zero/biocreative/function.mat"
                     "D:/Data/data_zero/biocreative/process.mat"]
    # print(file_path)
    a = [1, 2, 4, 8, 16, 32, 64, 128, 256]
    bag_status = ['g', 'p', 'n']
    embed_status = ['add', 'con']
    # DIEPredict(file_path, bag_status[2], embed_status[1], 0.01, 5)
    # DIEPredict(file_path, bag_status[2], embed_status[1], 0.01, 6)
    # DIEPredict(file_path, bag_status[2], embed_status[1], 0.01, 7)
    # DIEPredict(file_path, bag_status[2], embed_status[1], 0.01, 8)
    # for i in range(len(file_path_all)):
    #     print(file_path_all[i], end="")
    test(file_path)
